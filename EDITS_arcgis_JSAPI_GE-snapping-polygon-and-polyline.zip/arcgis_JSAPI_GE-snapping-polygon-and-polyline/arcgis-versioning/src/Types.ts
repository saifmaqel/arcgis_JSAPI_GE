import React from 'react'

export type coordinatesType = {
  x: number
  y: number
}

export type InputFieldType = {
  distance: number
}
